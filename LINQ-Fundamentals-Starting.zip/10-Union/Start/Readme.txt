﻿To run this project in Visual Studio Code, open the LINQSamples.code-workspace
  When prompted to add "Required Assets", Click the 'Yes' button
  Run the project
  Check the DEBUG CONSOLE window for the output
To run this project in Visual Studio 2022, open the LINQSamples.sln
  Run the project
  A console window shows the output


SampleViewModel Samples
--------------------------------------------------
UnionIntegers() - Union() combines two lists together, but skips duplicates by using a comparer class. This is like the UNION SQL operator.
Union() - Union() combines two lists together, but skips duplicates by using a comparer class. This is like the UNION SQL operator.

UnionBy() - UnionBy() combines two lists together using DISTINCT on the property specified

ConcatIntegers() - The LINQ Concat() operator combines two lists together, but does NOT check for duplicates
Concat() - The LINQ Concat() operator combines two lists together, but does NOT check for duplicates
