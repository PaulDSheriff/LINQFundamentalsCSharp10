﻿namespace LINQSamples
{
  public partial class ProductSales
  {
    public Product Product { get; set; }
    public List<SalesOrder> Sales { get; set; }
  }
}
