﻿namespace LINQSamples
{
  public class SaleProducts
  {
    public int SalesOrderID { get; set; }
    public List<Product> Products { get; set; }
  }
}
