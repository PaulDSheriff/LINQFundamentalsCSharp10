using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 3
  /// </summary>
  [TestClass]
  public class Module03Tests
  {
    [TestMethod]
    public void GetAllCustomers()
    {
      Module03ViewModel vm = new();

      var list = vm.GetAllCustomers();
            
      Assert.AreEqual(list.Count, 23);
    }

    [TestMethod]
    public void GetProductNameAndPrice()
    {
      Module03ViewModel vm = new();

      var list = vm.GetProductNameAndPrice();

      Assert.IsNotNull(list[0].ProductName);
      Assert.IsNotNull(list[0].Price);
      Assert.IsNull(list[0].Category);
    }
  }
}