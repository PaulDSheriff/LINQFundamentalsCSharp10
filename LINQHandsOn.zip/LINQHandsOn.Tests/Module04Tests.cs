using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 4
  /// </summary>
  [TestClass]
  public class Module04Tests
  {   
    [TestMethod]
    public void OrderProductsByName()
    {
      Module04ViewModel vm = new();

      var list = vm.OrderProductsByName();

      Assert.AreEqual(list[0].ProductName, "ACDelco Alternator");
    }

    [TestMethod]
    public void OrderProductsByCategoryPrice()
    {
      Module04ViewModel vm = new();

      var list = vm.OrderProductsByCategoryPrice();

      Assert.AreEqual(list[0].Category, "Wax");
      Assert.AreEqual(list[0].Price, 7.79M);
    }
  }
}