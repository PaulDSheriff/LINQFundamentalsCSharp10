using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 5
  /// </summary>
  [TestClass]
  public class Module05Tests
  {
    [TestMethod]
    public void GetCustomersByEmail()
    {
      Module05ViewModel vm = new();

      var list = vm.GetCustomersByEmail();
            
      Assert.AreEqual(list.Count, 3);
    }

    [TestMethod]
    public void GetProductsBetweenYears()
    {
      Module05ViewModel vm = new();

      var list = vm.GetProductsBetweenYears();

      Assert.AreEqual(list.Count, 17);
    }
  }
}