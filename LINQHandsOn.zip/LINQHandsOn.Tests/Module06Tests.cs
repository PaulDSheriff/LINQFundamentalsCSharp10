using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 6
  /// </summary>
  [TestClass]
  public class Module06Tests
  {
    [TestMethod]
    public void GetSingleProduct()
    {
      Module06ViewModel vm = new();

      var product = vm.GetSingleProduct();

      Assert.AreEqual(product.ProductName, "PurolatorBOSS Air Filter");
    }

    [TestMethod]
    public void GetFirstProductWithCategoryOfBatteries()
    {
      Module06ViewModel vm = new();

      var product = vm.GetFirstProductWithCategoryOfBatteries();

      Assert.AreEqual(product.Category, "Batteries");
    }
  }
}