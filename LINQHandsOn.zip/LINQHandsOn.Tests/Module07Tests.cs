using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 7
  /// </summary>
  [TestClass]
  public class Module07Tests
  {
    [TestMethod]
    public void GetFirstFiveCustomers()
    {
      Module07ViewModel vm = new();

      var list = vm.GetFirstFiveCustomers();

      Assert.AreEqual(list.Count, 5);
    }

    [TestMethod]
    public void GetCustomersFiveThroughTen()
    {
      Module07ViewModel vm = new();

      var list = vm.GetCustomersFiveThroughTen();

      Assert.AreEqual(list[0].CustomerId, 4007);
    }

    [TestMethod]
    public void SkipOrdersWhereCustomerOne()
    {
      Module07ViewModel vm = new();

      var list = vm.SkipOrdersWhereCustomerOne();

      Assert.AreEqual(list[0].OrderHeaderId, 8);
    }

    [TestMethod]
    public void GetDistinctCategories()
    {
      Module07ViewModel vm = new();

      var list = vm.GetDistinctCategories();

      Assert.IsTrue(list.Count == 17);
      Assert.AreEqual(list[0].Category, "Alternators");
    }

    [TestMethod]
    public void SplitCustomersIntoGroupsOfThree()
    {
      Module07ViewModel vm = new();

      var list = vm.SplitCustomersIntoGroupsOfThree();

      Assert.AreEqual(list.Count, 8);
      Assert.AreEqual(list[0].Length, 3);
    }

  }
}