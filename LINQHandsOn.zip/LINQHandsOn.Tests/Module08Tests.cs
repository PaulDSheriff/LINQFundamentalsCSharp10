using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 8
  /// </summary>
  [TestClass]
  public class Module08Tests
  {
    [TestMethod]
    public void AllProductCategoriesContainSpace()
    {
      Module08ViewModel vm = new();

      var value = vm.AllProductCategoriesContainSpace();

      Assert.IsFalse(value);
    }

    [TestMethod]
    public void AnyCustomerLastNamesStartWithW()
    {
      Module08ViewModel vm = new();

      var value = vm.AnyCustomerLastNamesStartWithW();

      Assert.IsTrue(value);
    }

    [TestMethod]
    public void SearchCustomersUsingComparerClass()
    {
      Module08ViewModel vm = new();

      var value = vm.SearchCustomersUsingComparerClass();

      Assert.IsTrue(value);
    }
  }
}