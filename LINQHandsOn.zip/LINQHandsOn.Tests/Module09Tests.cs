using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 9
  /// </summary>
  [TestClass]
  public class Module09Tests
  {
    [TestMethod]
    public void AreTwoCustomerCollectionsEqual()
    {
      Module09ViewModel vm = new();

      var value = vm.AreTwoCustomerCollectionsEqual();

      Assert.IsFalse(value);
    }

    [TestMethod]
    public void FindProductsNotInCommon()
    {
      Module09ViewModel vm = new();

      var list = vm.FindProductsNotInCommon();

      Assert.AreEqual(list.Count, 4);
    }

    [TestMethod]
    public void FindProductsInCommon()
    {
      Module09ViewModel vm = new();

      var list = vm.FindProductsInCommon();

      Assert.AreEqual(list.Count, 30);
    }

    [TestMethod]
    public void FindDistinctProductsInCommon()
    {
      Module09ViewModel vm = new();

      var list = vm.FindDistinctProductsInCommon();

      Assert.AreEqual(list.Count, 2);
    }
  }
}