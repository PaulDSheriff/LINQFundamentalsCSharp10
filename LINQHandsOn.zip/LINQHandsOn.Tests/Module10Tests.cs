using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 10
  /// </summary>
  [TestClass]
  public class Module10Tests
  {
    [TestMethod]
    public void UnionProductDataOnCategoryAndPrice()
    {
      Module10ViewModel vm = new();

      var list = vm.UnionProductDataOnCategoryAndPrice();

      Assert.AreEqual(list.Count, 4);
    }

    [TestMethod]
    public void ConcatCustomers()
    {
      Module10ViewModel vm = new();

      var list = vm.ConcatCustomers();

      Assert.AreEqual(list.Count, 5);
    }

  }
}