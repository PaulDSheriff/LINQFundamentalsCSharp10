using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 11
  /// </summary>
  [TestClass]
  public class Module11Tests
  {
    [TestMethod]
    public void JoinOrderHeadersAndDetails()
    {
      Module11ViewModel vm = new();

      var list = vm.JoinOrderHeadersAndDetails();

      Assert.IsTrue(list.Count == 54);
    }

    [TestMethod]
    public void CreateHeaderAndDetails()
    {
      Module11ViewModel vm = new();

      var list = vm.CreateHeaderAndDetails();

      Assert.IsTrue(list.Count == 31);
      Assert.IsTrue(list[0].Details.Count == 3);
    }
  }
}