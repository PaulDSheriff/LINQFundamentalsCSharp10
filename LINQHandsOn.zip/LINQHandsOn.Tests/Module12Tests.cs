using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 12
  /// </summary>
  [TestClass]
  public class Module12Tests
  {
    [TestMethod]
    public void GroupProductsByCategoryUsingKey()
    {
      Module12ViewModel vm = new();

      var list = vm.GroupProductsByCategoryUsingKey();

      Assert.IsTrue(list.Count == 17);
    }

    [TestMethod]
    public void GroupProductsByCategoryUsingWhere()
    {
      Module12ViewModel vm = new();

      var list = vm.GroupProductsByCategoryUsingWhere();

      Assert.IsTrue(list.Count == 3);
    }
  }
}