using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 13
  /// </summary>
  [TestClass]
  public class Module13Tests
  {
    [TestMethod]
    public void CountOrdersWithProductID()
    {
      Module13ViewModel vm = new();

      var value = vm.CountOrdersWithProductID();

      Assert.AreEqual(value, 6);
    }

    [TestMethod]
    public void MinimumPriceOnAllOrders()
    {
      Module13ViewModel vm = new();

      var value = vm.MinimumPriceOnAllOrders();

      Assert.AreEqual(value, 5.59M);
    }

    [TestMethod]
    public void MaximumPriceReturnOrderDetail()
    {
      Module13ViewModel vm = new();

      var value = vm.MaximumPriceReturnOrderDetail();

      Assert.AreEqual(value.OrderDetailId, 5);
    }

    [TestMethod]
    public void SumPriceOnAllOrders()
    {
      Module13ViewModel vm = new();

      var value = vm.SumPriceOnAllOrders();

      Assert.AreEqual(value, 5806.46M);
    }
  }
}