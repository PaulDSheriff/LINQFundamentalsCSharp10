using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LINQHandsOn.Tests
{
  /// <summary>
  /// Tests for your queries for Module 14
  /// </summary>
  [TestClass]
  public class Module14Tests
  {
    [TestMethod]
    public void CalculateTotalSalesForCustomer()
    {
      Module14ViewModel vm = new();

      var list = vm.CalculateTotalSalesForCustomer();

      Assert.AreEqual(list[0].TotalSales, 5441.14M);
    }
  }
}