﻿namespace LINQHandsOn
{
  public class ViewModelBase
  {
    #region GetCustomers Method
    protected List<Customer> GetCustomers()
    {
      // Get all Customer Data
      return CustomerRepository.GetAll();
    }
    #endregion

    #region GetProducts Method
    protected List<Product> GetProducts()
    {
      // Get all Product Data
      return ProductRepository.GetAll();
    }
    #endregion

    #region GetOrderHeaders Method
    protected List<OrderHeader> GetOrderHeaders()
    {
      // Get all Order Header Data
      return OrderHeaderRepository.GetAll();
    }
    #endregion

    #region GetOrderDetails Method
    protected List<OrderDetail> GetOrderDetails()
    {
      // Get all Order Detail Data
      return OrderDetailRepository.GetAll();
    }
    #endregion

    #region Display Methods
    public void Display(List<Customer> customers)
    {
      foreach (Customer customer in customers)
      {
        Console.Write(customer);
      }

      Console.WriteLine();
      Console.WriteLine($"Total Customers: {customers.Count}");
    }

    public void Display(List<Product> products)
    {
      foreach (Product product in products)
      {
        Console.Write(product);
      }

      Console.WriteLine();
      Console.WriteLine($"Total Products: {products.Count}");
    }

    public void Display(List<Order> orders)
    {
      foreach (Order order in orders)
      {
        Console.Write(order);
      }

      Console.WriteLine();
      Console.WriteLine($"Total Orders: {orders.Count}");
    }

    public void Display(List<HeaderAndDetails> orders)
    {
      foreach (HeaderAndDetails order in orders)
      {
        Console.WriteLine($"Order Header ID: {order.Header.OrderHeaderId}");

        if (order.Details.Count > 0)
        {
          // Loop through the details in each header
          foreach (OrderDetail detail in order.Details)
          {
            Console.Write("   ");
            Console.WriteLine(detail);            
          }
        }
        else
        {
          Console.WriteLine("   No details found for this header.");
        }
        Console.WriteLine();
      }

      Console.WriteLine();
      Console.WriteLine($"Total Orders: {orders.Count}");
    }

    public void Display(List<Product[]> collection)
    {
      int count = 1;
      foreach (Product[] products in collection)
      {
        Console.WriteLine($"Chunk: {count++}");
        Console.WriteLine(new string('-', 40));
        foreach (Product product in products)
        {
          Console.Write(product);
        }
      }
    }

    public void Display(List<Customer[]> collection)
    {
      int count = 1;
      foreach (Customer[] customers in collection)
      {
        Console.WriteLine($"Chunk: {count++}");
        Console.WriteLine(new string('-', 40));
        foreach (Customer cust in customers)
        {
          Console.Write(cust);
        }
      }
    }

    public void Display(List<IGrouping<string, Product>> collection)
    {
      // Loop through each category
      foreach (var group in collection)
      {
        // The value in the 'Key' property is 
        // whatever data you grouped upon
        Console.WriteLine($"Category: {group.Key}  Count: {group.Count()}");

        // Loop through the products in each category
        foreach (Product product in group)
        {
          Console.Write("   ");
          Console.WriteLine(product);
        }
      }

      Console.WriteLine();
      Console.WriteLine($"Total Categories: {collection.Count}");
    }

    public void Display(List<OrderHeader> orders)
    {
      foreach (OrderHeader order in orders)
      {
        Console.Write(order);
      }

      Console.WriteLine();
      Console.WriteLine($"Total Order Headers: {orders.Count}");
    }

    public void Display(List<OrderDetail> details)
    {
      foreach (OrderDetail detail in details)
      {
        Console.Write(detail);
      }

      Console.WriteLine();
      Console.WriteLine($"Total Order Details: {details.Count}");
    }
        
    public void Display(List<string> items)
    {
      foreach (string item in items)
      {
        Console.WriteLine(item);
      }

      Console.WriteLine();
      Console.WriteLine($"Total Items: {items.Count}");
    }

    public void Display(List<int> items)
    {
      foreach (int item in items)
      {
        Console.WriteLine(item);
      }

      Console.WriteLine();
      Console.WriteLine($"Total Items: {items.Count}");
    }

    public void Display(Customer value)
    {
      Console.WriteLine(value);
    }

    public void Display(Product value)
    {
      Console.WriteLine(value);
    }

    public void Display(OrderHeader value)
    {
      Console.WriteLine(value);
    }

    public void Display(OrderDetail value)
    {
      Console.WriteLine(value);
    }

    public void Display(string value)
    {
      Console.WriteLine($"Value is '{value}'");
    }

    public void Display(int value)
    {
      Console.WriteLine($"Value is '{value}'");
    }

    public void Display(decimal value)
    {
      Console.WriteLine($"Value is '{value:c}'");
    }

    public void Display(bool value)
    {
      Console.WriteLine($"Value is '{value}'");
    }
    #endregion
  }
}
