﻿namespace LINQHandsOn
{
  public class HeaderAndDetails
  {
    public OrderHeader Header { get; set; }
    public List<OrderDetail> Details { get; set; }
  }
}
