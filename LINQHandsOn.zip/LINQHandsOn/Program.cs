﻿using LINQHandsOn;

// Create instance of view model
Module13ViewModel vm = new();

// Call Method You Wrote
var result = vm.SumPriceOnAllOrders();

// Display Results
vm.Display(result);