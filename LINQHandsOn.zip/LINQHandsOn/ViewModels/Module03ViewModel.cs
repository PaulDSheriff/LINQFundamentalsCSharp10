﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 3
  /// </summary>
  public class Module03ViewModel : ViewModelBase
  {
    #region GetAllCustomers
    /// <summary>
    /// Write a LINQ query to get all customers and put into a new list.
    /// </summary>
    public List<Customer> GetAllCustomers()
    {
      List<Customer> customers = GetCustomers();
      List<Customer> list = null;

      // Write Your Query Here


      return list;
    }
    #endregion

    #region GetProductNameAndPrice
    /// <summary>
    /// Write a LINQ query to get all products, create a new Product object, but only set the ProductName and Price properties.
    /// </summary>
    public List<Product> GetProductNameAndPrice()
    {
      List<Product> products = GetProducts();
      List<Product> list = null;

      // Write Your Query Here


      return list;
    }
    #endregion
  }
}
