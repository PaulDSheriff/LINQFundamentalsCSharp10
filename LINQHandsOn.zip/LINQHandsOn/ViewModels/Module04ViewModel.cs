﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 4
  /// </summary>
  public class Module04ViewModel : ViewModelBase
  {
    #region OrderProductsByName
    /// <summary>
    /// Write a LINQ query to get all products and order the results by the ProductName property
    /// </summary>
    public List<Product> OrderProductsByName()
    {
      List<Product> products = GetProducts();
      List<Product> list = null;

      // Write Your Query Here
      

      return list;
    }
    #endregion

    #region OrderProductsByCategoryPrice
    /// <summary>
    /// Write a LINQ query to get all products and order the results by the Category property in descending order and then the Price property in ascending order.
    /// </summary>
    public List<Product> OrderProductsByCategoryPrice()
    {
      List<Product> products = GetProducts();
      List<Product> list = null;

      // Write Your Query Here
      

      return list;
    }
    #endregion
  }
}
