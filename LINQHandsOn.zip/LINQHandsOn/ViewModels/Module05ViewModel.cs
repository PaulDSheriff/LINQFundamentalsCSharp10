﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 5
  /// </summary>
  public class Module05ViewModel : ViewModelBase
  {
    #region GetCustomersByEmail
    /// <summary>
    /// Write a LINQ query to get those customers where the EmailAddress contains the string 'mortco.com'.
    /// </summary>
    public List<Customer> GetCustomersByEmail()
    {
      List<Customer> customers = GetCustomers();
      List<Customer> list = null;

      // Write Your Query Here
      

      return list;
    }
    #endregion

    #region GetProductsBetweenYears
    /// <summary>
    /// Write a LINQ query to get products where the YearBegin property is greater than or equal to 2016 and the YearEnd property is less than or equal to 2021.
    /// </summary>
    public List<Product> GetProductsBetweenYears()
    {
      List<Product> products = GetProducts();
      List<Product> list = null;

      // Write Your Query Here
      

      return list;
    }
    #endregion
  }
}
