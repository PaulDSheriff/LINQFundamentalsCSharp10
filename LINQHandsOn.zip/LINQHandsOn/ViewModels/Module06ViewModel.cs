﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 6
  /// </summary>
  public class Module06ViewModel : ViewModelBase
  {
    #region GetSingleProduct
    /// <summary>
    /// Write a LINQ query to retrieve a single product where the ProductId property is equal to 20.
    /// </summary>
    public Product GetSingleProduct()
    {
      List<Product> products = GetProducts();
      Product product = null;

      // Write Your Query Here
     

      return product;
    }
    #endregion

    #region GetFirstProductWithCategoryOfBatteries
    /// <summary>
    /// Write a LINQ query to retrieve just the first Product object where the Category property is equal to "Batteries".
    /// </summary>
    public Product GetFirstProductWithCategoryOfBatteries()
    {
      List<Product> products = GetProducts();
      Product product = null;

      // Write Your Query Here
     

      return product;
    }
    #endregion
  }
}
