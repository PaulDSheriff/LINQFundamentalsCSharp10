﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 7
  /// </summary>
  public class Module07ViewModel : ViewModelBase
  {
    #region GetFirstFiveCustomers
    /// <summary>
    /// Write a LINQ query to get just the first five customers.
    /// </summary>
    public List<Customer> GetFirstFiveCustomers()
    {
      List<Customer> customers = GetCustomers();
      List<Customer> list = null;

      // Write Your Query Here
      

      return list;
    }
    #endregion

    #region GetCustomersFiveThroughTen
    /// <summary>
    /// Write a LINQ query to get customers 5 through 10.
    /// </summary>
    public List<Customer> GetCustomersFiveThroughTen()
    {
      List<Customer> customers = GetCustomers();
      List<Customer> list = null;

      // Write Your Query Here
     

      return list;
    }
    #endregion

    #region SkipOrdersWhereCustomerOne
    /// <summary>
    /// Write a LINQ query to skip orders where the CustomerId property is equal to 1.
    /// </summary>
    public List<OrderHeader> SkipOrdersWhereCustomerOne()
    {
      List<OrderHeader> orders = GetOrderHeaders();
      List<OrderHeader> list = null;

      // Write Your Query Here
      

      return list;
    }
    #endregion

    #region GetDistinctCategories
    /// <summary>
    /// Write a LINQ query to get all distinct categories and return a list of Product objects sorted by the Category property.
    /// </summary>
    public List<Product> GetDistinctCategories()
    {
      List<Product> products = GetProducts();
      List<Product> list = null;

      // Write Your Query Here
      

      return list;
    }
    #endregion

    #region SplitCustomersIntoGroupsOfThree
    /// <summary>
    /// Write a LINQ query to split the customer collection into an array of 3 customers each.
    /// </summary>
    public List<Customer[]> SplitCustomersIntoGroupsOfThree()
    {
      List<Customer> customers = GetCustomers();
      List<Customer[]> list = null;

      // Write Your Query Here
      

      return list;
    }
    #endregion
  }
}
