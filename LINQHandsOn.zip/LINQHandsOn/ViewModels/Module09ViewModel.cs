﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 9
  /// </summary>
  public class Module09ViewModel : ViewModelBase
  {
    #region AreTwoCustomerCollectionsEqual
    /// <summary>
    /// Write a LINQ query to return true if two customer collections are equal using a Customer Comparer class.
    /// </summary>
    public bool AreTwoCustomerCollectionsEqual()
    {
      List<Customer> list1 = GetCustomers();
      List<Customer> list2 = GetCustomers();
      CustomerComparer pc = new();
      bool value = true;

      list1.RemoveAt(0);

      // Write Your Query Here
      

      return value;
    }
    #endregion

    #region FindProductsNotInCommon
    /// <summary>
    /// Write a LINQ query to return a list of products NOT in common between two lists.
    /// </summary>
    public List<Product> FindProductsNotInCommon()
    {
      List<Product> list1 = GetProducts();
      List<Product> list2 = GetProducts();
      ProductComparer pc = new();
      List<Product> list = null;

      // Make lists different by removing some categories
      list2.RemoveAll(p => p.Category == "Spark Plugs" || 
                      p.Category == "Alternators");

      // Write Your Query Here


      return list;
    }
    #endregion

    #region FindProductsInCommon
    /// <summary>
    /// Write a LINQ query to return a list products that ARE in common between two lists.
    /// </summary>
    public List<Product> FindProductsInCommon()
    {
      List<Product> list1 = GetProducts();
      List<Product> list2 = GetProducts();
      ProductComparer pc = new();
      List<Product> list = null;

      // Make lists different by removing some categories
      list2.RemoveAll(p => p.Category == "Spark Plugs" ||
                      p.Category == "Alternators");

      // Write Your Query Here


      return list;
    }
    #endregion

    #region FindDistinctProductsInCommon
    /// <summary>
    /// Write a LINQ query to return a set of products that match a set of categories.
    /// </summary>
    public List<Product> FindDistinctProductsInCommon()
    {
      List<Product> products = GetProducts();
      List<Product> list = null;

      // List of categories to locate
      List<string> categories = new() { "Spark Plugs", "Batteries" };
      
      // Write Your Query Here
     

      return list;
    }
    #endregion
  }
}
