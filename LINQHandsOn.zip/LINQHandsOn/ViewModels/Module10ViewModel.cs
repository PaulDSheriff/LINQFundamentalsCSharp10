﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 10
  /// </summary>
  public class Module10ViewModel : ViewModelBase
  {
    #region UnionProductDataOnCategoryAndPrice Method
    /// <summary>
    /// Write a LINQ query to union two products lists together using the ProductComparer class
    /// </summary>
    public List<Product> UnionProductDataOnCategoryAndPrice()
    {
      ProductComparer pc = new();
      List<Product> list = null;
      // Load Products With Category = "Spark Plugs"
      List<Product> list1 = ProductRepository.GetAll().Where(p => p.Category == "Spark Plugs").ToList();
      // Load Products Where Price > 200
      List<Product> list2 = ProductRepository.GetAll().Where(p => p.Price > 200).ToList();

      // Write Your Query Here
      

      return list;
    }
    #endregion

    #region ConcatCustomers Method
    /// <summary>
    /// Write a LINQ query to return a list of customers by adding one list to another
    /// </summary>
    public List<Customer> ConcatCustomers()
    {
      List<Customer> list = null;
      // Load Customers by Email Address
      List<Customer> list1 = CustomerRepository.GetAll().Where(c => c.EmailAddress.Contains("xyzcorp")).ToList();
      // Load Customers by Email Address
      List<Customer> list2 = CustomerRepository.GetAll().Where(p => p.EmailAddress.Contains("mortco")).ToList();

      // Write Your Query Here
      

      return list;
    }
    #endregion
  }
}
