﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 11
  /// </summary>
  public class Module11ViewModel : ViewModelBase
  {
    #region JoinOrderHeadersAndDetails
    /// <summary>
    /// Write a LINQ query to create a new Order class by joining the OrderHeader and OrderDetail objects based on the OrderHeaderId property.
    /// </summary>
    public List<Order> JoinOrderHeadersAndDetails()
    {
      List<OrderHeader> headers = GetOrderHeaders();
      List<OrderDetail> details = GetOrderDetails();
      List<Order> list = null;

      // Write Your Query Here
      

      return list;
    }
    #endregion

    #region CreateHeaderAndDetails
    /// <summary>
    /// Write a LINQ query to create a new HeaderAndDetails class by joining the OrderHeader and OrderDetail objects. The Header property is the single OrderHeader object and the Details property is the list of OrderDetail objects that match the OrderHeaderId.
    /// </summary>
    public List<HeaderAndDetails> CreateHeaderAndDetails()
    {
      List<HeaderAndDetails> list = null;
      List<OrderHeader> headers = GetOrderHeaders();
      List<OrderDetail> details = GetOrderDetails();

      // Write Query Syntax Here
      

      return list;
    }
    #endregion
  }
}
