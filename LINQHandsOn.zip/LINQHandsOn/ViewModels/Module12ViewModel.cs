﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 12
  /// </summary>
  public class Module12ViewModel : ViewModelBase
  {
    #region GroupProductsByCategoryUsingKey
    /// <summary>
    /// Write a LINQ query to group product objects by category. Use the Key property for ordering by categories.
    /// </summary>
    public List<IGrouping<string, Product>> GroupProductsByCategoryUsingKey()
    {
      List<IGrouping<string, Product>> list = null;
      List<Product> products = GetProducts();

      // Write Query Syntax Here
      

      return list;
    }
    #endregion

    #region GroupProductsByCategoryUsingWhere
    /// <summary>
    /// Write a LINQ query to group products by category. After grouping, include only those categories where the Category property starts with the letter 'A'.
    /// </summary>
    public List<IGrouping<string, Product>> GroupProductsByCategoryUsingWhere()
    {
      List<IGrouping<string, Product>> list = null;
      List<Product> products = GetProducts();

      // Write Query Syntax Here


      return list;
    }
    #endregion
  }
}
