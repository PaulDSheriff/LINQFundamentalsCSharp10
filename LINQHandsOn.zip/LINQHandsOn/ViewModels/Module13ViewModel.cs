﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 13
  /// </summary>
  public class Module13ViewModel : ViewModelBase
  {
    #region CountOrdersWithProductID
    /// <summary>
    /// Write a LINQ query to return the count all OrderDetail objects where the ProductId property is equal to 8.
    /// </summary>
    public int CountOrdersWithProductID()
    {
      int value = 0;
      List<OrderDetail> details = GetOrderDetails();

      // Write Query Syntax Here
      

      return value;
    }
    #endregion

    #region MinimumPriceOnOrders
    /// <summary>
    /// Write a LINQ query to return the minimum of the Price property on all OrderDetail objects.
    /// </summary>
    public decimal MinimumPriceOnAllOrders()
    {
      decimal value = 0;
      List<OrderDetail> details = GetOrderDetails();

      // Write Query Syntax Here
      

      return value;
    }
    #endregion

    #region MaximumPriceReturnOrderDetail
    /// <summary>
    /// Write a LINQ query to return the maximum of the Price property on all OrderDetail objects.
    /// </summary>
    public OrderDetail MaximumPriceReturnOrderDetail()
    {
      OrderDetail value = null;
      List<OrderDetail> details = GetOrderDetails();

      // Write Query Syntax Here
      

      return value;
    }
    #endregion

    #region SumPriceOnAllOrders
    /// <summary>
    /// Write a LINQ query to return the sum of the Price property on all OrderDetail objects.
    /// </summary>
    public decimal SumPriceOnAllOrders()
    {
      decimal value = 0;
      List<OrderDetail> details = GetOrderDetails();

      // Write Query Syntax Here


      return value;
    }
    #endregion
  }
}
