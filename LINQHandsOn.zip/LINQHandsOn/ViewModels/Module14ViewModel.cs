﻿namespace LINQHandsOn
{
  /// <summary>
  /// In this class you write your LINQ queries to test your knowledge from the topics in Module 14
  /// </summary>
  public class Module14ViewModel : ViewModelBase
  {
    #region CalculateTotalSalesForCustomer
    /// <summary>
    /// Write a LINQ query to set the TotalSales property on the Customer class by summing up the sales for that customer in the OrderDetail list.
    /// </summary>
    public List<Customer> CalculateTotalSalesForCustomer()
    {
      List<Customer> customers = CustomerRepository.GetAll();
      List<OrderDetail> orders = OrderDetailRepository.GetAll();

      // Write Query Syntax Here


      return customers;
    }
    #endregion
  }
}
