﻿Hands-On Exercises: Visual Studio Code
===============================================================================
Open the LINQHandsOn.code-workspace
When prompted to add "Required Assets", Click the 'Yes' button
Select the menu Terminal | Run Task... | test LINQHandsOn.Tests


Hands-On Exercises: Visual Studio 2022
===============================================================================
Open the LINQHandsOn.sln
Select the menu Test | Run All Tests


Creating your Hands-On Exercises
===============================================================================
After watching each module, open the corresponding Module??ViewModel.cs class
  For example, after watching Module 3, open Module03ViewModel.cs
Go to the first #region and expand that region
Locate the <summary> comments above the method and follow the instuctions on the LINQ query to write

After you write the LINQ query, open the corresponding Module??Test.cs class
Run the test that has the same method name as the one in which you wrote your LINQ query
If you have written the query successfully, the test should pass.